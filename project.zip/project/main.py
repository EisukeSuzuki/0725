import cv2
import os
import numpy as np

# 顔認識モデル（Haar Cascade）を読み込み
face_cascade = cv2.CascadeClassifier(cv2.data.haarcascades + 'haarcascade_frontalface_default.xml')

# 登録された顔画像（テンプレート）を読み込み
def load_known_faces(folder_path='faces'):
    known_faces = {}
    for person in os.listdir(folder_path):
        person_folder = os.path.join(folder_path, person)
        for filename in os.listdir(person_folder):
            img_path = os.path.join(person_folder, filename)
            img = cv2.imread(img_path, cv2.IMREAD_GRAYSCALE)
            faces = face_cascade.detectMultiScale(img, 1.3, 5)
            for (x, y, w, h) in faces:
                face_img = cv2.resize(img[y:y+h, x:x+w], (100, 100))
                known_faces[person] = face_img
                break  # 1枚だけ使う
    return known_faces

# 顔の類似度を比較（単純なMSEベース）
def compare_faces(face1, face2):
    if face1.shape != face2.shape:
        return float('inf')
    diff = np.mean((face1.astype("float") - face2.astype("float")) ** 2)
    return diff

# メイン処理
def main():
    known_faces = load_known_faces()
    if not known_faces:
        print("顔データが見つかりませんでした")
        return

    cap = cv2.VideoCapture(0)

    while True:
        ret, frame = cap.read()
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        faces = face_cascade.detectMultiScale(gray, 1.3, 5)

        for (x, y, w, h) in faces:
            roi = cv2.resize(gray[y:y+h, x:x+w], (100, 100))

            best_match = None
            lowest_score = float('inf')

            for name, known_face in known_faces.items():
                score = compare_faces(roi, known_face)
                if score < lowest_score:
                    lowest_score = score
                    best_match = name

            if lowest_score < 2000:  # 適当なしきい値（調整可）
                label = f"Match: {best_match}"
            else:
                label = "Unknown"

            cv2.rectangle(frame, (x, y), (x+w, y+h), (255, 0, 0), 2)
            cv2.putText(frame, label, (x, y-10),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.8, (0, 255, 0), 2)

        cv2.imshow("Face Detection", frame)

        if cv2.waitKey(1) & 0xFF == ord("q"):
            break

    cap.release()
    cv2.destroyAllWindows()

if __name__ == "__main__":
    main()
